// ===== LOGISTICS HERO MOTION TWEAKS =====
document.addEventListener('DOMContentLoaded', function() {
    const hero = document.getElementById('hero-headline');
    const wrapper = document.getElementById('hero-wrapper');
    
    if (hero && wrapper) {
        wrapper.addEventListener('mousemove', function(e) {
            const rect = wrapper.getBoundingClientRect();
            const xPercent = (e.clientX - rect.left) / rect.width;
            const yPercent = (e.clientY - rect.top) / rect.height;
            
            // Industrial slight sliding translation offset based on cursor tracking
            const translateX = (xPercent - 0.5) * 20;
            const translateY = (yPercent - 0.5) * 10;
            
            hero.style.transform = `translateX(${translateX}px) translateY(${translateY}px)`;
            hero.style.transition = 'transform 0.1s ease-out';
        });
        
        wrapper.addEventListener('mouseleave', function() {
            hero.style.transform = `translateX(0px) translateY(0px)`;
            hero.style.transition = 'transform 0.5s ease-out';
        });
    }

    // FORM HANDLING PROTOTYPE
    const form = document.getElementById('email-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const button = this.querySelector('button');
            button.textContent = 'TRANSMITTED';
            button.style.background = '#10b981';
            setTimeout(() => {
                button.textContent = 'Notify me';
                button.style.background = '';
                this.reset();
            }, 2500);
        });
    }
});

// ===== CARGO VECTOR ENGINE (FANCY ROUTE BACKGROUND) =====
const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');
document.body.appendChild(canvas);

canvas.style.position = 'fixed';
canvas.style.top = '0';
canvas.style.left = '0';
canvas.style.width = '100%';
canvas.style.height = '100%';
canvas.style.zIndex = '0';
canvas.style.pointerEvents = 'none';

let hubs = [];
let routes = [];
let cargoPulses = [];

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    generateLogisticsNetwork();
}
window.addEventListener('resize', resizeCanvas);

// Setup structural static network hubs and vectors
function generateLogisticsNetwork() {
    hubs = [];
    routes = [];
    cargoPulses = [];

    // Scale number of nodes based on viewport footprint
    const totalHubs = Math.floor((canvas.width * canvas.height) / 45000) + 8;

    // Generate static logistic coordinate centers
    for (let i = 0; i < totalHubs; i++) {
        hubs.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            radius: Math.random() * 2 + 1.5
        });
    }

    // Establish route matrices between nearby centers
    for (let i = 0; i < hubs.length; i++) {
        let connections = 0;
        for (let j = i + 1; j < hubs.length; j++) {
            let dx = hubs[i].x - hubs[j].x;
            let dy = hubs[i].y - hubs[j].y;
            let distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 250 && connections < 3) {
                routes.push({ start: hubs[i], end: hubs[j] });
                connections++;
            }
        }
    }
}

// Spawns traveling dynamic data particles along active paths
function dispatchCargo() {
    if (routes.length === 0) return;
    
    // Throttle spawning limits
    if (cargoPulses.length < routes.length * 1.5) {
        // Choose a random path vector
        const chosenRoute = routes[Math.floor(Math.random() * routes.length)];
        
        // Randomize directional transit orientation
        const reverse = Math.random() > 0.5;
        
        cargoPulses.push({
            route: chosenRoute,
            progress: 0,
            speed: (Math.random() * 0.004) + 0.002, // Controlled velocity
            reverse: reverse,
            size: Math.random() * 2 + 1
        });
    }
}

function runEngine() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 1. Draw static route vectors (Thin structural network wires)
    ctx.lineWidth = 0.7;
    routes.forEach(route => {
        ctx.strokeStyle = 'rgba(51, 65, 85, 0.25)'; // Muted grid color
        ctx.beginPath();
        ctx.moveTo(route.start.x, route.start.y);
        ctx.lineTo(route.end.x, route.end.y);
        ctx.stroke();
    });

    // 2. Draw Distribution Hub Locations
    hubs.forEach(hub => {
        ctx.beginPath();
        ctx.arc(hub.x, hub.y, hub.radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(148, 163, 184, 0.3)';
        ctx.fill();
    });

    // 3. Update & Render Moving Cargo Pulses (Tasteful, directional motion streams)
    dispatchCargo();

    for (let i = cargoPulses.length - 1; i >= 0; i--) {
        let p = cargoPulses[i];
        p.progress += p.speed;

        if (p.progress >= 1) {
            cargoPulses.splice(i, 1); // Destination reached, clear node
            continue;
        }

        // Interpolate current linear coordinates along vector path
        let startPoint = p.reverse ? p.route.end : p.route.start;
        let endPoint = p.reverse ? p.route.start : p.route.end;

        let currentX = startPoint.x + (endPoint.x - startPoint.x) * p.progress;
        let currentY = startPoint.y + (endPoint.y - startPoint.y) * p.progress;

        // Draw energetic moving pulse
        ctx.beginPath();
        ctx.arc(currentX, currentY, p.size, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(194, 87, 12, 0.85)'; // Energetic Orange cargo point
        ctx.fill();

        // Subtle motion trail tail element
        let tailProgress = Math.max(0, p.progress - 0.04);
        let tailX = startPoint.x + (endPoint.x - startPoint.x) * tailProgress;
        let tailY = startPoint.y + (endPoint.y - startPoint.y) * tailProgress;

        ctx.beginPath();
        ctx.moveTo(currentX, currentY);
        ctx.lineTo(tailX, tailY);
        ctx.strokeStyle = 'rgba(194, 87, 12, 0.3)';
        ctx.lineWidth = p.size;
        ctx.stroke();
    }

    requestAnimationFrame(runEngine);
}

// Initialize system loop
resizeCanvas();
runEngine();